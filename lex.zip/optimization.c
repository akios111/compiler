#include <stdio.h>
#include <stdlib.h>
#include "optimization.h"

// Καθολικές μεταβλητές για βελτιστοποιήσεις βρόχων
typedef struct {
    int unroll_factor;
    bool vectorize;
    bool parallelize;
} loop_info;

static loop_info current_loop_info = {1, false, false};

// Ορισμός παράγοντα ξεδίπλωσης βρόχου
void set_unroll_factor(ic_node* loop, int factor) {
    if (factor > 0) {
        current_loop_info.unroll_factor = factor;
    }
}

// Σήμανση βρόχου για διανυσματοποίηση
void mark_for_vectorization(ic_node* loop) {
    current_loop_info.vectorize = true;
}

// Σήμανση βρόχου για παραλληλοποίηση
void mark_for_parallelization(ic_node* loop) {
    current_loop_info.parallelize = true;
}

// Κύρια συνάρτηση βελτιστοποίησης
void optimize_code(void) {
    // TODO: Εφαρμογή βελτιστοποιήσεων στον ενδιάμεσο κώδικα
    // Προς το παρόν απλά εκτυπώνουμε τις επιλογές βελτιστοποίησης
    printf("Loop optimizations:\n");
    printf("  Unroll factor: %d\n", current_loop_info.unroll_factor);
    printf("  Vectorization: %s\n", current_loop_info.vectorize ? "enabled" : "disabled");
    printf("  Parallelization: %s\n", current_loop_info.parallelize ? "enabled" : "disabled");
} 