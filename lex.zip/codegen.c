#ifndef CODEGEN_C
#define CODEGEN_C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "codegen.h"

static int label_counter = 0;
static int temp_counter = 0;

// Δημιουργία νέας ετικέτας
char* new_label(void) {
    char buf[32];
    sprintf(buf, "L%d", label_counter++);
    return strdup(buf);
}

// Δημιουργία νέας προσωρινής μεταβλητής
temp_var* new_temp(symbol_type_t type) {
    temp_var* t = malloc(sizeof(temp_var));
    char buf[32];
    sprintf(buf, "t%d", temp_counter++);
    t->name = strdup(buf);
    t->type = type;
    t->is_constant = false;
    return t;
}

// Προσθήκη κώδικα στη λίστα
void append_code(ic_node* code) {
    // TODO: Προσθήκη στη λίστα ενδιάμεσου κώδικα
}

// Ενημέρωση ετικετών
void backpatch(ic_node* list, const char* label) {
    // TODO: Ενημέρωση των ετικετών στη λίστα
}

// Δημιουργία λίστας από μια εντολή
ic_node* make_list(int instr) {
    // TODO: Δημιουργία λίστας
    return NULL;
}

// Επόμενος αριθμός εντολής
int next_instr(void) {
    static int counter = 0;
    return counter++;
}

// Παραγωγή εντολών
ic_node* gen_binary(ic_type_t op, temp_var* result, temp_var* op1, temp_var* op2) {
    ic_node* node = malloc(sizeof(ic_node));
    node->type = op;
    // TODO: Συμπλήρωση πεδίων
    return node;
}

ic_node* gen_assign(temp_var* result, temp_var* value) {
    ic_node* node = malloc(sizeof(ic_node));
    node->type = IC_ASSIGN;
    // TODO: Συμπλήρωση πεδίων
    return node;
}

ic_node* gen_goto(const char* label) {
    ic_node* node = malloc(sizeof(ic_node));
    node->type = IC_GOTO;
    // TODO: Συμπλήρωση πεδίων
    return node;
}

ic_node* gen_if_goto(temp_var* cond, temp_var* target) {
    ic_node* node = malloc(sizeof(ic_node));
    node->type = IC_IF_GOTO;
    // TODO: Συμπλήρωση πεδίων
    return node;
}

ic_node* gen_label(const char* label) {
    ic_node* node = malloc(sizeof(ic_node));
    node->type = IC_LABEL;
    // TODO: Συμπλήρωση πεδίων
    return node;
}

ic_node* gen_call(const char* func, ic_node** args, int num_args) {
    ic_node* node = malloc(sizeof(ic_node));
    node->type = IC_CALL;
    // TODO: Συμπλήρωση πεδίων
    return node;
}

ic_node* gen_do_start(const char* var, temp_var* start, temp_var* end) {
    ic_node* node = malloc(sizeof(ic_node));
    node->type = IC_DO_START;
    // TODO: Συμπλήρωση πεδίων
    return node;
}

ic_node* gen_do_end(ic_node* start) {
    ic_node* node = malloc(sizeof(ic_node));
    node->type = IC_DO_END;
    // TODO: Συμπλήρωση πεδίων
    return node;
}

#endif