#include <stdio.h>
#include "error.h"

extern int line_number;

void yyerror(const char* msg) {
    fprintf(stderr, "Error at line %d: %s\n", line_number, msg);
} 