#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "intermediate.h"
#include "types.h"
#include "codegen.h"
#include "optimization.h"

// Καθολικές μεταβλητές
extern int yyparse(void);
extern FILE* yyin;
ic_node* ic_head = NULL;

// Επιλογές βελτιστοποίησης
struct {
    int optimization_level;
    bool verify_optimizations;
    bool show_optimization_stats;
    bool loop_optimizations;
    bool vectorization;
    bool parallelization;
} options = {
    .optimization_level = 0,
    .verify_optimizations = false,
    .show_optimization_stats = false,
    .loop_optimizations = true,
    .vectorization = false,
    .parallelization = false
};

// Στατιστικά βελτιστοποίησης
struct {
    int functions_inlined;
    int loops_unrolled;
    int variables_eliminated;
    int expressions_simplified;
    int memory_accesses_optimized;
} stats = {0};

// Δηλώσεις συναρτήσεων
void generate_code(FILE* out);
void generate_instruction(ic_node* node, FILE* out);

int main(int argc, char* argv[]) {
    // Επεξεργασία παραμέτρων γραμμής εντολών
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-O0") == 0) {
            options.optimization_level = 0;
        }
        else if (strcmp(argv[i], "-O1") == 0) {
            options.optimization_level = 1;
        }
        else if (strcmp(argv[i], "-O2") == 0) {
            options.optimization_level = 2;
        }
        else if (strcmp(argv[i], "-O3") == 0) {
            options.optimization_level = 3;
        }
        else if (strcmp(argv[i], "-verify") == 0) {
            options.verify_optimizations = true;
        }
        else if (strcmp(argv[i], "-stats") == 0) {
            options.show_optimization_stats = true;
        }
        else if (strcmp(argv[i], "-vec") == 0) {
            options.vectorization = true;
        }
        else if (strcmp(argv[i], "-par") == 0) {
            options.parallelization = true;
        }
        else {
            // Άνοιγμα αρχείου εισόδου
            yyin = fopen(argv[i], "r");
            if (!yyin) {
                fprintf(stderr, "Cannot open input file: %s\n", argv[i]);
                return 1;
            }
        }
    }

    // Συντακτική ανάλυση
    if (yyparse() != 0) {
        fprintf(stderr, "Parsing failed\n");
        return 1;
    }

    // Βελτιστοποίηση
    if (options.optimization_level > 0) {
        optimize_code();
    }

    // Παραγωγή κώδικα
    FILE* out = fopen("output.asm", "w");
    if (!out) {
        fprintf(stderr, "Cannot create output file\n");
        return 1;
    }

    generate_code(out);
    fclose(out);

    return 0;
}

// Παραγωγή κώδικα
void generate_code(FILE* out) {
    // Επικεφαλίδα
    fprintf(out, "; Generated code\n\n");
    fprintf(out, "section .text\n");
    fprintf(out, "global main\n\n");

    // Παραγωγή εντολών
    ic_node* current = ic_head;
    while (current) {
        generate_instruction(current, out);
        current = current->next;
    }
}

// Παραγωγή μιας εντολής
void generate_instruction(ic_node* node, FILE* out) {
    // TODO: Υλοποίηση παραγωγής assembly για κάθε τύπο εντολής
    switch (node->type) {
        case IC_BINARY:
            // Παραγωγή κώδικα για δυαδικές πράξεις
            break;
        case IC_ASSIGN:
            // Παραγωγή κώδικα για αναθέσεις
            break;
        case IC_GOTO:
            printf("\tgoto L%d\n", node->label);
            break;
        case IC_IF_GOTO:
            printf("\tif %s goto L%d\n", node->result, node->label);
            break;
        case IC_LABEL:
            printf("L%d:\n", node->label);
            break;
        case IC_CALL:
            printf("\tcall %s\n", node->result);
            break;
        case IC_DO_START:
            printf("\tdo_start %s = %s to %s step %s\n", 
                   node->result, node->arg1, node->arg2, node->arg3 ? node->arg3 : "1");
            break;
        case IC_DO_END:
            printf("\tdo_end\n");
            break;
        // ... άλλοι τύποι εντολών
    }
}