#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symtab.h"
#include "codegen.h"

#define HASH_SIZE 211

static symbol_entry* hash_table[HASH_SIZE];

// Απλή hash function
static unsigned int hash(const char* str) {
    unsigned int hash = 0;
    while (*str) hash = hash * 31 + *str++;
    return hash % HASH_SIZE;
}

// Αρχικοποίηση πίνακα συμβόλων
void init_symbol_table(void) {
    memset(hash_table, 0, sizeof(hash_table));
}

// Εισαγωγή συμβόλου
void add_symbol(const char* name, symbol_type_t type) {
    unsigned int h = hash(name);
    symbol_entry* entry = malloc(sizeof(symbol_entry));
    entry->name = strdup(name);
    entry->type = type;
    entry->temp = new_temp(type);  // Δημιουργία προσωρινής μεταβλητής
    entry->next = hash_table[h];
    hash_table[h] = entry;
    printf("Added symbol: %s, type: %d\n", name, type);  // Debugging εκτύπωση
}

// Αναζήτηση συμβόλου
symbol_entry* lookup_symbol(const char* name) {
    unsigned int h = hash(name);
    symbol_entry* entry = hash_table[h];
    while (entry) {
        if (strcmp(entry->name, name) == 0) {
            printf("Found symbol: %s\n", name);  // Debugging εκτύπωση
            return entry;
        }
        entry = entry->next;
    }
    printf("Symbol not found: %s\n", name);  // Debugging εκτύπωση
    return NULL;
}

// Προσθήκη common block
void add_common_block(const char* name, char** vars, int num_vars) {
    // TODO: Υλοποίηση common block
}

// Επεξεργασία data item
void process_data_item(const char* name, int* values, int num_values) {
    // TODO: Υλοποίηση data item
} 