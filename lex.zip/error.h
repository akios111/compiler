#ifndef ERROR_H
#define ERROR_H

void yyerror(const char* msg);

#endif